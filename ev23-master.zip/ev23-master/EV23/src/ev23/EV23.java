/*
 * this product is an unlicensed as I am to drive
 * 
 * but hey, enjoy it anyway!
 */
package ev23;

import frames.StartFrame;

/**
 *
 * @author Scott
 */
public class EV23 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        StartFrame game = new StartFrame();
        game.setVisible(true); 
    }
    
}
