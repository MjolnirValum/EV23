/*
 * this product is an unlicensed as I am to drive
 * 
 * but hey, enjoy it anyway!
 */
package labparty2020;

/**
 *
 * @author Scott
 */
public class LabParty2020 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("aloha");
    }
    
}
