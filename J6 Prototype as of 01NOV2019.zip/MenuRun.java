/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//package edu.wiu.cs491;

/**
 *
 * @author asche
 */
public class MenuRun {
    public static void main(String[] args){
        //do stuff here
        MainMenuFrame mainMenuFrame = new MainMenuFrame();
        mainMenuFrame.setVisible(true);
    }
    

}
